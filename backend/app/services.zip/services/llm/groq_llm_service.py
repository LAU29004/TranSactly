import json

from groq import Groq

from app.config.settings import settings

# ──────────────────────────────────────────────────────────────────────────────
# Groq client
# ──────────────────────────────────────────────────────────────────────────────
client = Groq(api_key=settings.GROQ_API_KEY)

# Model used for all classification calls in this module.
# llama-3.3-70b-versatile -> highest quality, slightly slower
# llama-3.1-8b-instant    -> fastest, good for simple classification tasks
GROQ_MODEL = "llama-3.3-70b-versatile"


# ──────────────────────────────────────────────────────────────────────────────
# Intent detection
# ──────────────────────────────────────────────────────────────────────────────
def detect_financial_intent(query: str) -> str:
    """
    Classify a user's natural-language query into one of the supported
    financial intents. Returns "unknown" if classification fails for
    any reason (model error, malformed JSON, etc.).
    """

    prompt = f"""
You are a financial AI intent classifier.
Classify the user query into ONE intent.

Possible intents:
- spending
- categories
- subscriptions
- anomaly
- savings
- income
- unknown

Return ONLY valid JSON.
Example:
{{"intent": "spending"}}

User Query:
{query}
"""

    try:
        response = client.chat.completions.create(
            model=GROQ_MODEL,
            messages=[
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"},
        )

        text = response.choices[0].message.content.strip()

        parsed = json.loads(text)
        return parsed.get("intent", "unknown")

    except Exception as e:
        print("GROQ INTENT PARSE ERROR:", e)
        return "unknown"


# ──────────────────────────────────────────────────────────────────────────────
# Merchant classification
# ──────────────────────────────────────────────────────────────────────────────
def classify_merchant(merchant: str) -> dict:
    """
    Classify a merchant name into a spending category with a confidence
    score. Returns {"category": "Other", "confidence": 0.5} if
    classification fails for any reason.
    """

    prompt = f"""
You are a financial merchant classifier.
Classify the merchant into ONE category.

Possible categories:
- Food
- Shopping
- Travel
- Entertainment
- Bills
- Income
- Transfer
- Healthcare
- Education
- Other

Return ONLY JSON.

Example:
{{
  "category": "Food",
  "confidence": 0.95
}}

Merchant:
{merchant}
"""

    try:
        response = client.chat.completions.create(
            model=GROQ_MODEL,
            messages=[
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"},
        )

        text = response.choices[0].message.content.strip()

        result = json.loads(text)
        return {
            "category": result.get("category", "Other"),
            "confidence": float(result.get("confidence", 0.5)),
        }

    except Exception as e:
        print("GROQ MERCHANT PARSE ERROR:", e)
        return {
            "category": "Other",
            "confidence": 0.5,
        }