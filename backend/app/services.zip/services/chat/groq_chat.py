from app.services.llm.groq_service import (
    client,
)

def is_finance_query(
    question: str,
):

    classifier_prompt = f"""
Determine whether the following query is related to personal finance.

Finance topics include:
- spending
- expenses
- savings
- income
- salary
- transactions
- merchants
- subscriptions
- budgeting
- investments
- financial health

Query:
{question}

Return ONLY one word:

FINANCE

or

NON_FINANCE
"""

    completion = client.chat.completions.create(

        model="llama-3.3-70b-versatile",

        messages=[
            {
                "role": "user",
                "content": classifier_prompt,
            }
        ],

        temperature=0,

        max_tokens=5,
    )

    result = (
        completion
        .choices[0]
        .message.content
        .strip()
        .upper()
    )

    return result == "FINANCE"

def answer_financial_question(
    question: str,
    context: str,
):
    if not is_finance_query(question):
        return{
                    "text":
        "I can help only with financial analysis, spending insights, income tracking, budgeting and transaction-related questions.",

        "insightType":
        "summary",

        "suggestions": [

            "How much did I save?",

            "Where am I spending most?",

            "Show top merchants",

            "How healthy are my finances?",
        ],
        }
    prompt = f"""
You are TranSactly AI.

You are a personal finance assistant.

IMPORTANT:

You are ONLY a financial assistant.

You may answer ONLY:

- spending analysis
- expense analysis
- savings
- income
- budgeting
- subscriptions
- merchants
- transaction insights
- financial habits

Never answer:

- coding
- programming
- politics
- religion
- sports
- entertainment
- medical questions
- legal questions
- general knowledge
- hacking
- cyber security

If asked anything unrelated to finance,
reply:

"I can help only with financial analysis, spending insights, income tracking, budgeting and transaction-related questions."

{context}

Question:

{question}

Answer clearly and concisely.
"""

    try:

        completion = (
            client.chat.completions.create(

                model=
                "llama-3.3-70b-versatile",

                messages=[
                    {
                        "role":
                        "user",

                        "content":
                        prompt,
                    }
                ],

                temperature=0.3,

                max_tokens=400,
            )
        )

        answer = (
            completion
            .choices[0]
            .message.content
        )

        return {

            "text":
            answer,

            "insightType":
            "summary",

            "suggestions": [

                "How much did I save?",

                "Where am I spending most?",

                "Show top merchants",

                "How healthy are my finances?",
            ],
        }

    except Exception as e:

        print(
            "GROQ ERROR:",
            str(e),
        )

        return {

            "text":
            "AI analysis is currently unavailable.",

            "insightType":
            "summary",
        }